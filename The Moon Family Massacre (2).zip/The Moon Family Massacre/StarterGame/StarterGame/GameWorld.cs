﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace StarterGame
{
    public class GameWorld
    {
        private static GameWorld _instance;
        public static GameWorld Instance 
        { 
            get 
            { 
                if (_instance == null)
                {
                    _instance = new GameWorld();
                }
                return _instance; 
            } 
        }
        
        private Room _entrance;

        //Checkpoint setter for GameWorld
        private GameCheckpoint _checkpoint;
        public GameCheckpoint Checkpoint
        {
            get { return _checkpoint; }
            internal set { _checkpoint = value; }
        }

        //Tracks all rooms entered, helps it track the save when using load
        private Dictionary<string, Room> _allRooms = new Dictionary<string, Room>();
        public Room Entrance { get { return _entrance; } private set { _entrance = value; } }
        private Room _exit;
        public Room Exit { get { return _exit; } private set { _exit = value; } }
        //Add reason for Enemy list**
        public List<Enemy> Enemies { get; } = new List<Enemy>();
        public Room SafeRoom { get; private set; }
  
        private Dictionary<Trigger, IWorldEvent> _events;
      
        private List<Enemy> _enemies;
        //Added this field to GameWorld to track the player
        private Player _player; //Store the reference to the player

        //Class Decorate (it helps make them only accessible if the player enters a specific room
        /*
        private Room Butcher_Closet;
        private Room Bathroom;
        private Room Tool_shed;

        private IItem Butcher_Knife;
        private IItem Flesh;
        private IItem SilverCross;
        private IItem Photo2;
        private IItem Photo3;
        private IItem NewBorn;
        */


        private GameWorld()
        {
            _events = new Dictionary<Trigger, IWorldEvent>();
            _enemies = new List<Enemy>();
            NotificationCenter.Instance.AddObserver("PlayerEnteredRoom", PlayerEnteredRoom);
            NotificationCenter.Instance.AddObserver("EnemyMoved", EnemyMoved);
            CreateWorld();

        }
        //New implementation: HashSet to track Checkpoint rooms
        private HashSet<Room> _checkpointRooms = new HashSet<Room>();

        public void SetPlayer(Player player)
        {
            _player = player;
        }

        public void RegisterRoom(Room room)
        {
            if (room != null && !string.IsNullOrEmpty(room.Tag))
            {
                _allRooms[room.Tag] = room;
            }
        }

        public bool HasEvent(Trigger trigger)
        {
            return _events.ContainsKey(trigger);
        }

        public void TriggerEvent(Trigger trigger)
        {
            if (_events.TryGetValue(trigger, out IWorldEvent worldEvent))
            {
                worldEvent.Execute();
                _events.Remove(trigger);
            }
        }
        public void AddWorldEvent(Trigger trigger, IWorldEvent worldEvent)
        {
            _events[trigger] = worldEvent;
        }

        public Dictionary<Trigger, IWorldEvent> PendingEvents()
        {
            return _events;
        }

        public IEnumerable<Enemy> GetEnemiesInRoom(Room room)
        {
            foreach (var enemy in _enemies)
            {
                if (enemy.CurrentRoom == room)
                {
                    yield return enemy;
                }
            }
        }

        public void SetCheckpoint(Room room, Player player)
        {
            if (room == null || player == null) return;

            // Create a deep copy of the inventory
            var inventoryCopy = new Dictionary<string, Item>();
            foreach (var entry in player.InventoryItems)
            {
                // Use the copy constructor or Copy method
                inventoryCopy[entry.Key] = new Item(entry.Value);
            }

            Checkpoint = new GameCheckpoint(room, inventoryCopy);
            player.NormalMessage($"Checkpoint set at {room.Tag}");
        }

        public void RestoreFromCheckpoint(Player player)
        {
            if (Checkpoint == null)
            {
                player.ErrorMessage("No checkpoint available");
                return;
            }

            // Restore player position
            player.CurrentRoom = Checkpoint.PlayerRoom;
            player.ClearRoomHistory();

            // Restore inventory
            player.ClearInventory();
            foreach (var item in Checkpoint.Inventory.Values)
            {
                player.AddToInventory(item);
            }

            player.NormalMessage($"Restored from checkpoint at {Checkpoint.PlayerRoom.Tag}");
        }


        public void PlayerEnteredRoom(Notification notification)
        {
            Player player = (Player)notification.Object;
            if (player != null)
            {
                // First check for enemies in the room
                var enemiesInRoom = GetEnemiesInRoom(player.CurrentRoom).ToList();
                if (enemiesInRoom.Any())
                {
                    foreach (var enemy in enemiesInRoom)
                    { 
                        // Trigger immediate attack
                        enemy.AttackPlayer(player);
                    }
                    return; // Skip other room entry logic when in combat
                }
                // Handles existing room entry logic
                if (player.CurrentRoom == Entrance)
                {
                    player.ErrorMessage("Player is back at the entrance");
                }
                if (player.CurrentRoom == Exit)
                {
                    player.ErrorMessage("Player is now at the exit");
                }
                // Checkpoint logic - save when entering designated rooms
                if (_checkpointRooms.Contains(player.CurrentRoom))
                {
                    SetCheckpoint(player.CurrentRoom, player);

                    // Also save the game automatically
                    GameSaveService saveService = new GameSaveService();
                    saveService.SaveGame(player);
                }

                if (_events.ContainsKey(player.CurrentRoom))
                {
                    IWorldEvent we = _events[player.CurrentRoom];
                    we.Execute();
                    player.WarningMessage("you changed the world!!");
                }


                // Hints to the player if there are items in the room
                if (player.CurrentRoom.Items.Count > 0)
                {
                    Random rand = new Random();
                    List<string> hints = new List<string>();

                    // Check for specific item types
                    // General item hints
                    hints.AddRange(new[] {
                        "You sense something might be worth examining here...",
                        "The air feels different here - maybe there's something nearby?",
                        "Your instincts tell you to look around carefully...",
                        "Something catches your attention in this area..."
                    });

                    try
                    {
                        bool hasContainer = player.CurrentRoom.Items.Values.Any(i => i is IItemContainer);
                        bool hasShootable = player.CurrentRoom.Items.Values.Any(i => i is IShootable);
                        bool hasNewItem = player.CurrentRoom.Items.Values.Any(i => (i as Item)?.IsNew == true);
                        // Container-specific hints
                        if (hasContainer)
                        {
                            hints.AddRange(new[] {
                            "There's a container here that might hold something useful...",
                            "You notice what appears to be a storage object in the room...",
                            "Something here looks like it could be opened or searched..."
                        });
                        }

                        // Shootable item hints
                        if (hasShootable)
                        {
                            hints.AddRange(new[] {
                            "Something here looks fragile or breakable...",
                            "You get the strange urge to test something in this room...",
                            "There's an object here that seems like it might react to force..."
                        });
                        }

                        // New item hints
                        if (hasNewItem)
                        {
                            hints.AddRange(new[] {
                            "Something seems different about this room since you last looked...",
                            "Was that always there? Something appears to have changed...",
                            "The environment seems subtly altered from before..."
                        });

                            // Mark items as no longer new
                            foreach (var item in player.CurrentRoom.Items.Values.Where(i => i.IsNew))
                            {
                                item.IsNew = false;
                            }
                        }
                    }
                    catch
                    {

                    }
                    string hint = hints[rand.Next(hints.Count)];
                    player.NormalMessage(hint);
                }
            }
        }
        
            
        

        // New method that handles enemy movements separately
        private void EnemyMoved(Notification notification)
        {
            Enemy enemy = (Enemy)notification.Object;
            Dictionary<string, object> userInfo = notification.UserInfo;

            Room fromRoom = userInfo["fromRoom"] as Room;
            Room toRoom = userInfo["toRoom"] as Room;

            //Notify the player if they are in the affected room
            Player player = GetPlayerInRooms(fromRoom, toRoom);
            if (player != null)
            {
                player.WarningMessage($"You hear the {enemy.Name} moving nearby...");
            }
        }

        //Helper method to find the player in specific rooms
        private Player GetPlayerInRooms(params Room[] rooms)
        {
            if (_player != null && rooms.Contains(_player.CurrentRoom))
            {
                return _player;
            }
            return null;
        }
        
        //Checks to see if the player has all requirements done, if so, they will win the game
        public void CheckWinCondition(Player player)
        {
            // Condition 1: Banished the Butcher and reached safe room
            bool hasBanishedButcher = Enemies.All(e => e.CurrentRoom == null);
            bool isSafeRoom = player.CurrentRoom == SafeRoom;

            // Condition 2: Has all 3 required items and reached safe room
            List<string> requiredItems = new List<string> { "Gun", "Heart of a Madman", "Fractured Skull" };
            bool hasRequiredItems = requiredItems.All(item =>
                player.InventoryItems.Values.Any(i =>
                    i.Name.Equals(item, StringComparison.OrdinalIgnoreCase)));

            if ((hasBanishedButcher && isSafeRoom) || (hasRequiredItems && isSafeRoom))
            {
                player.NormalMessage("\nYou've escaped the house! YOU WIN!");
                if (hasRequiredItems)
                {
                    player.NormalMessage("You managed to escape with the key evidence items!");
                }
                else
                {
                    player.NormalMessage("You banished the Butcher and escaped safely!");
                }
                NotificationCenter.Instance.PostNotification(new Notification("PlayerWon", player));
            }
        }

        public void CheckEnemyInteractions(Player player)
        {
            foreach (var enemy in Enemies.Where(e => e.CurrentRoom == player.CurrentRoom))
            {
                enemy.AttackPlayer(player);
            }
        }

        public Room GetRoomByName(string roomTag)
        {
            // Check all rooms created in CreateWorld()
            if (string.IsNullOrEmpty(roomTag))
                return null;

            // Check the dictionary first
            if (_allRooms.TryGetValue(roomTag, out Room room))
                return room;
            // Add checks for other important rooms if needed
            if (Entrance != null && Entrance.Tag.Equals(roomTag, StringComparison.OrdinalIgnoreCase))
                return Entrance;
            if (Exit != null && Exit.Tag.Equals(roomTag, StringComparison.OrdinalIgnoreCase))
                return Exit;
            if (SafeRoom != null && SafeRoom.Tag.Equals(roomTag, StringComparison.OrdinalIgnoreCase))
                return SafeRoom;

            return null; // Room not found
        }


        private Room CreateWorld()
        {

            //Items 
            //Keys to unlock doors
            Item rustedKey = new Item("Rusted key", "It seems to unlock the door in the basement", 1, 2);
            Item silverKey = new Item("Silver key", "Emits a purified glow, seems to unlock a nasty door...", 1, 2);
            Item oldKey = new Item("Old key", "An old key that somehow never rusted. Something about this key is off...", 1, 2);
            Item scrapKey = new Item("Scrap Key", "A scraped key that was molded by the scraped remains of other keys", 3, 2);
            Item BloodiedKey = new Item("Bloodied Key", "A key still stained with blood. It beckons you towards an area...", 2, 2);
            Item woodenKey = new Item("Wooden Key", "A piece of wood carved to look like a key", 2, 1);

            //Items needed to leave the house
            Item Gun = new Item("Gun", "Its a pistol that belonged to someone else, and it still works", 4, 5);
            Item Heart = new Item("Heart of a Madman", "A beating heart that follows the rhythm of your breathing", 4, 4);
            Item Skull = new Item("Fractured Skull", "A underdeveloped skull that has a fracture in the middle of the forehead", 3, 3);

            //Items needed to banish the Butcher
            Item Tongue = new Item("Severed Tongue", "A severed tongue that can somehow whisper sinister plots...", 1, 1);


            Item CrackedMirror = new Item.CrackedMirror("Mirror", "A near broken mirror that....looks somehow hollow", 50, 50);
            Item Hollow_Wall = new Item.Hollow_Wall("Hollowed wall", "A Hollowed wall that looks easily breakable with enough force", 50, 50);

            //Decorators to change items
            IItem Knife = new Item("Knife", "The butcher's knife, its simply unsettling to look at...", 1, 2);
            IItem Water = new Item("Water", "Along with a sealed water glass", 2, 4);
            IItem Photo = new Item("Photo", ", and a simple photo of the Mother.", 1, 1);

            IItem SilverCross = new Item("Silver Crossed", "A silver cross that seems to belong to the wife. It harbors a sense of purity.", 5, 2);
            IItem Flesh = new Item("Flesh", "Flesh freshly carved from a well build man.", 2, 2);
            IItem Butcher_Knife = new Item("Butcher's", "Drowned in sorrow and sin.", 3, 3);
            IItem Photo2 = new Item("Purified", "A simple photo of three children. Seeing them smile soothes your sanity,", 2, 2);
            IItem Photo3 = new Item("Final", "A simple photo of a husband. I can sense a dark presence within it,", 1, 1);



            //Shootable items
            //_player.Shoot("Rusted Lock");
            //_player.Shoot("Near broken Mirror");
            //_player.Shoot("Hollowed wall");



            //Rooms inside the house
            Room Porch = new Room("You are now outside on the porch");
            RegisterRoom(Porch);
            Room Library = new Room("You are inside of the Library, a place made for knowledge, now in ruin...");
            RegisterRoom(Library);
            Room Main_Hall = new Room("You are in the main hall, a place for socialization, now known as a way to explore this dreaded house!");
            RegisterRoom(Main_Hall);
            Room Parlor = new Room("You are in the parlor, used to represent status, now represents the decay of their precious instruments.");
            RegisterRoom(Parlor);
            Room Kitchen = new Room("You are now in the kitchen, which went from cooking meals, to cooking up the victims before you...");
            RegisterRoom(Kitchen);
            Room Pantry = new Room("You are now in the pantry, it stinks of rot and soot. Its best to keep your search minimal.");
            RegisterRoom(Pantry);
            Room Dining_Room = new Room("You are now in the dining room. It's riddled with mold and cobwebs. This could have looked beautiful before.");
            RegisterRoom(Dining_Room);

            //First set of stairs for the basement
            Room Stairs = new Room("You are now at the stairs. Darkness lingers upstairs, who knows what danger lurks above...");
            RegisterRoom(Stairs);

            //Second Stairs for the Main_Hall
            Room Second_Stairs = new Room("You are now in the second set of stairs. Darkness still lingers above, you feel as though your being watched");
            RegisterRoom(Second_Stairs);

            //Third set of stairs for the Upper part of the house
            Room Third_Stairs = new Room("You are now in the third set of stairs. Darkness now lingers below you, the upper part begs for your attention...");
            RegisterRoom(Third_Stairs);
                
            Room BedRoom_Ch = new Room("You are now in the children's bedroom. You can sense joy in here, but the blood on the bed sheets brings back the dread");
            RegisterRoom(BedRoom_Ch);
            Room Bathroom = new Room("You are now in the children's bathroom. You don't like it here, one of them seemed to have died here...");
            RegisterRoom(Bathroom);
            Room Second_Hall = new Room("You are now in the second hall. It feels weirdly clean here....almost like someone kept it clean to save themselves the pain...");
            RegisterRoom(Second_Hall);
            Room BedRoom_HW = new Room("You are now in the family bedroom. It's oddly clean, but you can still smell the stench of flesh underneath.");
            RegisterRoom(BedRoom_HW);

            //This will be locked as well
            Room Alter = new Room("You are now at the alter. A well kept memorial for the family long past. The air strangely makes your eyes heavy...");
            RegisterRoom(Alter);

            Room Closet = new Room("You are now in the closet, and it reeks with soiled clothes. However, you do sense something is amiss here...");
            RegisterRoom(Closet);
            Room Main_Bathroom = new Room("You are now in the main bathroom. Comfort fills your body as it remains normal, considering the house your in");
            RegisterRoom(Main_Bathroom);

            Room Tool_shed = new Room("You are now in the toolshed. It harbors numerous objects that can be used for your escape");
            RegisterRoom(Tool_shed);

            //Hidden if you don't use a gun
            Room Hidden_Wall = new Room("You are in a hidden room that harbors holy essence. This could be a cry for help from the family, to put them out of their misery...");
            RegisterRoom(Hidden_Wall);

            Room Balcony = new Room("You are now on the balcony. You could just jump off, but your quite sure you will not survive.");
            RegisterRoom(Balcony);
            Room Recording_Station = new Room("You are inside of the recording station you set up before things went wrong. Maybe there is something here you can use?");
            RegisterRoom(Recording_Station);
            Room Butcher_Shop = new Room("You are now in the butcher's shop. This should not be possible, it was not here before! Well, that is probably what the corpses hanging said too...");
            RegisterRoom(Butcher_Shop);
            Room Basement_Hall = new Room("You are now in the basement hall. Before it looked like any other basement, but now its riddled with the stench of blood.");
            RegisterRoom(Basement_Hall);
            Room Spare_Parts = new Room("You are now in a room filled with scraps. This could be what all the victims had before their death. There could be something helpful here");
            RegisterRoom(Spare_Parts);
            Room Washing_Room = new Room("You are now in a washing room. The washing machine is clearly not washing clothes, but what could it be hiding in its mist of red...");
            RegisterRoom(Washing_Room);

            //This will be locked
            Room Butcher_Closet = new Room("You are now in the butcher's closet. From top to bottom, nothing but unnerving weapons.");
            RegisterRoom(Butcher_Closet);

            //Exits for all rooms
            Porch.SetExit("north", Main_Hall);
            
            Main_Hall.SetExit("north", Second_Stairs);
            Main_Hall.SetExit("south", Porch);
            Main_Hall.SetExit("east", Library);
            Main_Hall.SetExit("west", Parlor);

            Second_Stairs.SetExit("north", Third_Stairs);
            Second_Stairs.SetExit("south", Main_Hall);
            Second_Stairs.SetExit("east", Kitchen);
            Second_Stairs.SetExit("west", Dining_Room);

            Library.SetExit("west", Main_Hall);
            Library.SetExit("north", Kitchen);

            Kitchen.SetExit("north", Pantry);
            Kitchen.SetExit("west", Main_Hall);
            Kitchen.SetExit("south", Library);

            Parlor.SetExit("east", Main_Hall);

            Dining_Room.SetExit("east", Main_Hall);

            Stairs.SetExit("north", Second_Stairs);
            Stairs.SetExit("south", Basement_Hall);
            Stairs.SetExit("west", Spare_Parts);
            Stairs.SetExit("east", Recording_Station);

            Basement_Hall.SetExit("south", Butcher_Shop);
            Basement_Hall.SetExit("east", Recording_Station);
            Basement_Hall.SetExit("west", Butcher_Closet);
            Basement_Hall.SetExit("north", Stairs);

            Butcher_Shop.SetExit("west", Basement_Hall);

            Recording_Station.SetExit("west", Basement_Hall);

            Butcher_Closet.SetExit("north", Washing_Room);
            Butcher_Closet.SetExit("east", Basement_Hall);

            Washing_Room.SetExit("east", Spare_Parts);

            Spare_Parts.SetExit("west", Washing_Room);
            Spare_Parts.SetExit("east", Basement_Hall);

            Third_Stairs.SetExit("north", Stairs);
            Third_Stairs.SetExit("south", Second_Hall);
            Third_Stairs.SetExit("east", BedRoom_Ch);
            Third_Stairs.SetExit("west", Main_Bathroom);

            Second_Hall.SetExit("north", Third_Stairs);
            Second_Hall.SetExit("east", BedRoom_HW);
            Second_Hall.SetExit("west", Alter);

            BedRoom_Ch.SetExit("north", Bathroom);
            BedRoom_Ch.SetExit("west", Second_Hall);

            Bathroom.SetExit("south", BedRoom_Ch);
           

            BedRoom_HW.SetExit("north", Second_Hall);
            BedRoom_HW.SetExit("west", Closet);
            BedRoom_HW.SetExit("south", Balcony);

            Closet.SetExit("east", BedRoom_HW);

            Balcony.SetExit("north", BedRoom_HW);

            Main_Bathroom.SetExit("west", Tool_shed);
            Main_Bathroom.SetExit("east", Second_Hall);

            Tool_shed.SetExit("east", Main_Bathroom);

            Alter.SetExit("east", Second_Hall);



            //Add Items in rooms
            //Added Items in basement
            Washing_Room.AddItem(silverKey);
            Recording_Station.AddItem(CrackedMirror);
            Butcher_Shop.AddItem(Knife);
            Butcher_Closet.AddItem(Heart);

            //Added Items in first floor
            Kitchen.AddItem(BloodiedKey);
            Library.AddItem(Photo);
            Library.AddItem(oldKey);
            Parlor.AddItem(woodenKey);
            Pantry.AddItem(Skull);


            //Added Items in second floor
            BedRoom_HW.AddItem(Hollow_Wall);
            Bathroom.AddItem(Water);
            Bathroom.AddItem(scrapKey);
            Closet.AddItem(Tongue);


            //Decorate Items
            Knife.Decorate(Butcher_Knife);
            Knife.Decorate(Flesh);
            Photo.Decorate(Photo2);
            Photo.Decorate(Photo3);
            Water.Decorate(SilverCross);


            // New Enemy
            Enemy Butcher = new Enemy("Butcher", Alter);
            Enemies.Add(Butcher);


            // hidden part of the world

            //_events[we.Trigger] = we;
            //_trigger = theGreen;
            //_toRoom = davidson;
            //_fromRoom = schuster;
            //_toDirection = "west";
            //_fromDirection = "east";


            //setup delegates
            //TrapRoom tr = new TrapRoom("Rusted key");
            //tr.Engaged = true;
            //scct.Delegate = tr;
            //tr.ContainingRoom = scct;

            //Chest that harbors items
            IItemContainer chest = new ItemContainer("Chest", "A worn out chest that could harbor unknown treasures", 50, 50);
            chest.Insert(rustedKey);
            chest.Insert(Gun);
            Spare_Parts.AddItem(chest);

            //New Locked Rooms
            // Bathroom - requires silver key OR old key
            TrapRoom bathroomTrap = new TrapRoom(
                new List<string> { "Silver key", "Old key" },
                "The key works! The bathroom door unlocks.",
                "The bathroom door is locked. You'll need a key to enter.",
                Bathroom,
                ConsoleColor.Green
                );
            BedRoom_Ch.Delegate = bathroomTrap;
            bathroomTrap.ContainingRoom = BedRoom_Ch;

            //Single Key trap (Wooden key)
            TrapRoom PantryTrap = new TrapRoom(new List<string> { "Wooden Key" },
                "The wooden key turns with sudden ease, and the locks falls to a hollowed thud.",
                null,
                Pantry,
                ConsoleColor.Yellow
                );
            Kitchen.Delegate = PantryTrap;
            PantryTrap.ContainingRoom = Kitchen;

            // Single-key lock (Rusted key)
            TrapRoom ButcherClosetTrap = new TrapRoom(new List<string> { "Rusted key" },
                "The rusted key turns with difficulty, but the lock clicks open!",
                "The door is securely locked. You'll need a key to proceed.",
                Butcher_Closet,
                ConsoleColor.Red
                );
            //ButcherClosetTrap.Engaged = true;
            Basement_Hall.Delegate = ButcherClosetTrap;
            ButcherClosetTrap.ContainingRoom = Basement_Hall;


            // Bedroom_HW - requires scrap key
            TrapRoom bedroomHwTrap = new TrapRoom(
                new List<string> { "Scrap Key" },
                "The scrap key fits perfectly! The bedroom door unlocks.",
                "The bedroom door is locked. You'll need a scrap key to enter.",
                BedRoom_HW,
                ConsoleColor.Cyan
            );
            Second_Hall.Delegate = bedroomHwTrap;
            bedroomHwTrap.ContainingRoom = Second_Hall;

            //Rooms with checkpoints in them
            _checkpointRooms.Add(Main_Hall); 
            _checkpointRooms.Add(Second_Hall);

            //tr1.ContainingRoom = universityHall;

            //davidson.Delegate = tr;

            EchoRoom echo = new EchoRoom();
            //parkingDeck.Delegate = echo;

            Entrance = Recording_Station;
            Exit = Porch;
            //Saferoom room (If there with required items, you win the game)
            SafeRoom = Porch;

            return Recording_Station;
        }

    }

}
