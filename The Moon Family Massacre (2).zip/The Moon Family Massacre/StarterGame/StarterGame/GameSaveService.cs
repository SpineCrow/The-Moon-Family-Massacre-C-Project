﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;

namespace StarterGame
{

    public class GameSaveService
    {
        private const string SaveDirectory = "saves";
        private readonly BinaryFormatter _formatter = new BinaryFormatter();

        public void SaveGame(Player player)
        {
            Directory.CreateDirectory(SaveDirectory);
            string filename = $"saves/save_{DateTime.Now:yyyyMMddHHmmss}.dat";

            var memento = CreateMemento(player);

            using (FileStream file = File.Create(filename))
            {
                _formatter.Serialize(file, memento);
            }

            player.NormalMessage($"Game saved successfully to {filename}");
        }

        public void LoadGame(Player player)
        {
            var saveFile = GetLatestSaveFile();
            if (saveFile == null)
            {
                player.ErrorMessage("No save files found.");
                return;
            }

            using (FileStream file = File.OpenRead(saveFile))
            {
                var memento = (GameMemento)_formatter.Deserialize(file);
                RestoreFromMemento(player, memento);
            }

            player.NormalMessage($"Game loaded successfully from {saveFile}");
        }

        private GameMemento CreateMemento(Player player)
        {
            return new GameMemento(
                player.CurrentRoom.Tag,
                player.InventoryItems.Values.ToList(),
                GameWorld.Instance.Checkpoint?.PlayerRoom?.Tag,
                GameWorld.Instance.Checkpoint?.Inventory?.Values.ToList()
            );
        }

        private void RestoreFromMemento(Player player, GameMemento memento)
        {
            // Restore player state
            Room targetRoom = GameWorld.Instance.GetRoomByName(memento.PlayerRoomTag);
            if (targetRoom != null)
            {
                // Clear the room history stack since we're loading a saved game
                player.ClearRoomHistory();

                // Set the player's current room directly
                player.CurrentRoom = targetRoom;

                // Restore inventory
                player.ClearInventory();
                foreach (Item item in memento.InventoryItems)
                {
                    player.AddToInventory(item);
                }
            }
            else
            {
                player.ErrorMessage($"Failed to find room with tag: {memento.PlayerRoomTag}");
            }

            // Restore checkpoint if it exists
            if (!string.IsNullOrEmpty(memento.CheckpointRoomTag))
            {
                Room checkpointRoom = GameWorld.Instance.GetRoomByName(memento.CheckpointRoomTag);
                if (checkpointRoom != null)
                {
                    GameWorld.Instance.Checkpoint = new GameCheckpoint(
                        checkpointRoom,
                        memento.CheckpointInventory.ToDictionary(i => i.Name, i => i)
                    );
                }
            }

            // Notify the game that the player has entered the room
            NotificationCenter.Instance.PostNotification(new Notification("PlayerEnteredRoom", player));
        }

        private string GetLatestSaveFile()
        {
            if (!Directory.Exists(SaveDirectory)) return null;

            return Directory.GetFiles(SaveDirectory, "*.dat")
                .OrderByDescending(f => new FileInfo(f).LastWriteTime)
                .FirstOrDefault();
        }
    }
}
    


