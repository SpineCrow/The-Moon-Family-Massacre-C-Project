﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StarterGame
{
    public interface ICapacity
    {
        // Maximum weight the container can hold
        float MaxWeight { get; }
        // Maximum volume the container can hold
        double MaxVolume { get; }
        // Current total weight of items in the container
        float CurrentWeight { get; }
        // Current total volume of items in the container
        double CurrentVolume { get; }
        // Checks if an item can be added without exceeding capacity limits
        bool CanAddItem(Item item);

    }
}
