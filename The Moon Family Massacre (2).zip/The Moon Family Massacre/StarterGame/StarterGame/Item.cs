﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace StarterGame
{
    [Serializable]
    public class Item : IItem, IShootable
    {
        // Base item properties
        private string _name;
        private string _description;
        private float _weight;
        private double _volume;
        private bool _isNew = true;

        // Properties with decorator support
        public virtual string Name 
        { 
            //Shorthand if-else statement)
            //Returns original name, otherwise returns decorator name, then original name
            get { return _decorator == null ? _name : _decorator.Name + " " + _name; } 
            set { _name = value; }
        }
        public virtual string Description
        {
            get { return _decorator == null ? _description : _decorator.Description + " " + _description; }
            set { _description = value; }
        }

        public virtual float Weight
        {
            get { return _weight + (_decorator == null ? 0 : _decorator.Weight); }
            set { _weight = value; }
        }

        public virtual double Volume
        {
            get { return _volume + (_decorator == null ? 0 : _decorator.Volume); }
            set { _volume = value; }
        }
        
        //Handles shootable objects made by player
        public virtual void OnShot(Player player)
        {
            //Default behavior when shot
            player.NormalMessage($"\nYou shoot the {Name}, but nothing happens.");
        }

        public string Id { get;  private set; } // This helps uniquely identify each item
        public IItem _decorator; //Added decorator to modify items 
        public IItem Decorator { get { return _decorator; } set { _decorator = value; } }
        public virtual bool IsContainer {  get { return false; } }

        //Add to Item.cs to regulate new items made during events
        public bool IsNew
        {
            get { return _isNew; }
            set { _isNew = value; }
        }

        // Constructors
        public Item() : this("Unnamed", "No Description", 0f, 0f) { }

        public Item(string name, string description, float weight, double volume)
        {
            _name = name;
            _description = description;
            _weight = weight;
            _volume = volume;
            Id = Guid.NewGuid().ToString(); // This generates a unique ID for each Item
            _decorator = null;
        }

        //Used for checkpoint to copy and save the Items already inherited
        public Item(Item other)
        {
            _name = other._name;
            _description = other._description;
            _weight = other._weight;
            _volume = other._volume;
            _isNew = other._isNew;
            Id = Guid.NewGuid().ToString(); // Generate new ID for the copy
            _decorator = other._decorator != null ? new Item(other._decorator as Item) : null;
        }

        // Decorator pattern implementation
        public void Decorate(IItem decorator)
        {
            if (_decorator == null)
            {
                _decorator = decorator;
            }
            else
            {
                _decorator.Decorate(decorator);
            }
        }

        // Gets formatted item information
        public string GetInfo()
        {
            string decoratorInfo = _decorator != null ? $" (Decorated with: {_decorator.Name})" : "";
            return $"{this.Name} - {this.Description} (Weight: {this.Weight}kg, Volume: {this.Volume}m³){decoratorInfo}";
        }

        // Removes decoration from item
        public void Undecorate()
        {
            if (_decorator != null)
            {
                _decorator = null;
            }
        }

        // Checks if item has specific decorator
        public bool HasDecorator(string decoratorName)
        {
            if (_decorator == null) return false;
            return _decorator.Name.Equals(decoratorName, StringComparison.OrdinalIgnoreCase);
        }

        override
        public string ToString()
        {
            return $"{Name}, weight: {Weight}kg, volume: {Volume}m^3";
        }


        // Special item subclasses with custom shoot behavior
        [Serializable]
        public class CrackedMirror : Item, IShootable
        {
            //To stop argument about the changes made with the item
            public CrackedMirror(string name, string description, float weight, double volume)
       : base(name, description, weight, volume)
            {
            }
            public override void OnShot(Player player)
            {
                // Creates new item when shot
                player.CurrentRoom.AddItem(new Item("Holy Essence", "The air is lighter around you, it soothes your sanity", 2, 2));
                player.NormalMessage("\nThe mirror shatters into pieces! It reveals itself a blinding light inside of its cage...");
            }
        }
        [Serializable]
        public class Hollow_Wall : Item, IShootable
        {
            public Hollow_Wall(string name, string description, float weight, double volume)
     : base(name, description, weight, volume)
            {
            }
            public override void OnShot(Player player)
            {
                // Reveals hidden room and adds item
                player.CurrentRoom.SetExit("east", GameWorld.Instance.GetRoomByName("Hidden_Wall"));
                player.NormalMessage("\nThe wall collapsed! Revealing a room of prayer long abandoned...");
                player.CurrentRoom.AddItem(new Item("Eye of Truth", "An eye that strangely resembles that of a beautiful woman...", 1, 1));
            }
        }
    }

}
