﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StarterGame
{
    public class Notification
    {
        // Name/identifier of the notification
        public String Name { get; set; }
        // The object sending the notification
        public Object Object { get; set; }
        // Additional data payload
        public Dictionary<String, Object> UserInfo { get; set; }

        // Constructor chain with default values
        public Notification() : this("NotificationName")
        {
        }
        // Constructor with just name
        public Notification(String name) : this(name, null)
        {
        }

        // Constructor with name and object
        public Notification(String name, Object obj) : this(name, obj, null)
        {
        }

        // Main constructor that sets all properties
        public Notification(String name, Object obj, Dictionary<String, Object> userInfo)
        {
            this.Name = name;
            this.Object = obj;
            this.UserInfo = userInfo;
        }
    }
}
