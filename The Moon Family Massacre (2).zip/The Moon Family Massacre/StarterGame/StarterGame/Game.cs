﻿using System.Collections;
using System.Collections.Generic;
using System;

namespace StarterGame
{
    /*
     * Fall 2024
     */
    public class Game
    {
        private Player _player;
        private Parser _parser;
        private bool _playing;
        private GameClock gm;
        private int _timeAlive;

        public Game()
        {
            //singleton design pattern
            //GameWorld gw = new GameWorld();

            // create a capacity object for the player
            Capacity playerCapacity = new Capacity(40f, 50.0);

            // instantiate the player with both a starting room and a capacity
            _player = new Player(GameWorld.Instance.Entrance, playerCapacity);
            _playing = true;
            //Notifies whether the player lost, or won
            NotificationCenter.Instance.AddObserver("PlayerDied", _ => _playing = false);
            NotificationCenter.Instance.AddObserver("PlayerWon", _ => _playing = false);
            _parser = new Parser(new CommandWords());
            //New implementation of clock
           // gm = new GameClock(1000);
            //_timeAlive = 30;
            //NotificationCenter.Instance.AddObserver("GameClockTick", ClockTick);
        }

        // New implementation
            //public void ClockTick(Notification notification)
            //{
                //Console.WriteLine("Clock Tick");
                //if (--_timeAlive < 0)
                //{
                    //Console.WriteLine("Time's Up");
                    //End();
                    //_playing = false;
                //}
            //}

     

        /**
     *  Main play routine.  Loops until end of play.
     */
        public void Play()
        {

            // Enter the main command loop.  Here we repeatedly read commands and
            // execute them until the game is over.
            while (_playing)
            {
                Console.Write("\n>");
                Command command = _parser.ParseCommand(Console.ReadLine());

                if (command == null)
                {
                    _player.ErrorMessage("I don't understand...");
                }
                else
                {
                    // Execute command and check if it requested exit
                    bool shouldExit = command.Execute(_player);

                    // Check game state after every command
                    GameWorld.Instance.CheckEnemyInteractions(_player);
                    GameWorld.Instance.CheckWinCondition(_player);

                    // Exit conditions:
                    if (shouldExit || !_playing)
                    {
                        break; //Exits Game Loop
                    }
                }
            }
        }


        public void Start()
        {
            _playing = true;
            _player.InfoMessage(Welcome());
        }

        public void End()
        {
            _playing = false;
            _player.InfoMessage(Goodbye());
        }

        public string Welcome()
        {
            return "The Moon Family House Massacre\n\n"
                 + "You are a news reporter named Madalyn, tasked with doing a documentary about the mysterious massacre at the Moon Family House in the 1960s.\n\n"
                 + "This house's tragedy is your one way ticket to pushing your career, so you ceased the opportunity to be the first into the house.\n\n"
                 + "As you set up your camera and equipment in the basement, the door suddenly locks on itself, and you begin to hear footsteps above you!\n\n"
                 + "No...it couldn't be! However, it is what your mind is making you believe, this house is still lived in, and now your trapped in it!\n\n"
                 + "You have no choice but to escape this house with your wits about. Your life is more precious than this damn job!"
                 + "\n\nWIN CONDITIONS:"
                 + "\n1. Collect the Gun, Heart of a Madmen, and Fractured Skull then escape to the Porch"
                 + "\n2. Banish the Butcher by collecting its weakness items then escape to the Porch"
                 + "\n\nType 'help' if you need help understanding the game.\n\n" + _player.CurrentRoom.Description(); // Current room description
        }

        public string Goodbye()
        {
            return "\nThank you for playing, Goodbye. \n";
        }

    }
}
