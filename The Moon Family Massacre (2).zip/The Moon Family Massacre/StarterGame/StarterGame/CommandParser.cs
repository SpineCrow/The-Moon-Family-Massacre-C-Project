﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StarterGame
{
    // Chain of Responsibility Pattern for parsing commands
    public abstract class CommandParser
    {
        protected CommandParser _nextParser; // Reference to next parser in chain

        public void SetNextParser(CommandParser nextParser)
        {
            _nextParser = nextParser; // Set next parser in chain
        }
        public abstract Command ParseCommand(string commandString);  // Abstract parse method
    }
    }

