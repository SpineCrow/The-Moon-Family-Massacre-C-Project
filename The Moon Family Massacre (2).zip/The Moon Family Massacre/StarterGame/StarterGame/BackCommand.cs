﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StarterGame
{
    public class BackCommand : Command
    {
        public BackCommand() : base()
        {
            this.Name = "back"; // Sets the command name to "back"
        }

        public override bool Execute(Player player)
        {
            if (player.TryGoBack()) // Attempts to move player back to previous room
            {
                return false;  // Success - continue game
            }
            player.ErrorMessage("\nYou can't go back further."); // Error if no previous room

            return false; // Continue game loop
        }
    }
}
