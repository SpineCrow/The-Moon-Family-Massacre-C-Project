﻿using System.Collections;
using System.Collections.Generic;
using System;

namespace StarterGame
{
    /*
     * Fall 2024
     */
    public class CommandWords
    {
        // Stores all available commands
        private Dictionary<string, Command> _commands;
        // Default command set
        private static Command[] _commandArray = { new GoCommand(), new QuitCommand(), new SayCommand(), new LookCommand(), new AddCommand(), new RemoveCommand(), new InspectCommand()};

        public CommandWords() : this(_commandArray) { } // Default constructor

        // Designated Constructor
        public CommandWords(Command[] commandList)
        {
            _commands = new Dictionary<string, Command>();
            foreach (Command command in commandList)
            {
                _commands[command.Name] = command; // Add each command to dictionary
            }
            Command help = new HelpCommand(this); // Special help command
            _commands[help.Name] = help;
        }

        public Command Get(string word)
        {
            Command command = null;
            _commands.TryGetValue(word, out command); // Retrieve command by name
            return command;
        }

        public string Description()
        {
            string commandNames = "";
            Dictionary<string, Command>.KeyCollection keys = _commands.Keys;
            foreach (string commandName in keys)
            {
                commandNames += " " + commandName; // Build string of all command names
            }
            return commandNames;
        }
    }
}
