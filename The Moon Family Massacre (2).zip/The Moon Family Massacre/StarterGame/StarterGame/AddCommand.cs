﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StarterGame
{
    public class AddCommand : Command
    {
        public AddCommand() : base()
        {
            this.Name = "add"; //Sets the command name to "add"
        }

        override
        public bool Execute(Player player)
        {
            if (this.HasSecondWord()) // Checks if there's a second word (item to add)
            {
                player.Add(this.SecondWord); // Calls player's Add method with the item name
            }
            else
            {
                player.WarningMessage("\nAdd what?"); // Shows warning if there is no item specified
            }
            return false; // Returns false to continue game loop
        }
    }
}
