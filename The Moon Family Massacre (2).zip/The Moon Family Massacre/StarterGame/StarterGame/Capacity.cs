﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace StarterGame
{
    public class Capacity : ICapacity
    {
        // Private fields for capacity limits and current usage
        private float _maxWeight;
        private double _maxVolume;
        private float _currentWeight;
        private double _currentVolume;

        // Public properties with getters
        public float MaxWeight { get { return _maxWeight; } }
        public double MaxVolume { get { return _maxVolume; } }
        public float CurrentWeight { get { return _currentWeight; } }
        public double CurrentVolume { get { return _currentVolume; } }

        public Capacity(float maxWeight, double maxVolume)
        {
            _maxWeight = maxWeight;
            _maxVolume = maxVolume;
            _currentWeight = 0f; // Initialize current values to 0
            _currentVolume = 0.0;
        }

        public bool CanAddItem(Item item)
        {
            // Checks if adding the item would exceed capacity limits
            return (_currentWeight + item.Weight <= _maxWeight) && (_currentVolume + item.Volume <= _maxVolume);
        }

        public void AddItem(Item item)
        {
            if (CanAddItem(item)) // Only add if capacity allows
            {
                // Reduce current weight and volume when removing item
                _currentWeight += item.Weight;
                _currentVolume += item.Volume;
            }
        }

        public void RemoveItem(Item item)
        {
            _currentVolume -= item.Volume;
            _currentWeight -= item.Weight;
        }
    }
}
