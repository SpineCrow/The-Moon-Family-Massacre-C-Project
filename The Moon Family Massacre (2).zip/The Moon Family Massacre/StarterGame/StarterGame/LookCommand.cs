﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StarterGame
{
    public class LookCommand : Command
    {
        public LookCommand() : base()
        {
            this.Name = "look";
        }

        public override bool Execute(Player player)
        {
            if (this.HasSecondWord())
            {
                player.Look(this.SecondWord);
            }
            else
            {
                player.Look("");
            }
            return false;
        }
    }
}
