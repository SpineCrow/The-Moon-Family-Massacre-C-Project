﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StarterGame
{
    [Serializable]
    public class ItemContainer : Item, IItemContainer
    {
        private Dictionary<string, IItem> _items; // Contained items


        //Makes sure ItemContainer properly implements IItem and exposes its contents
        // Make the Items property more robust
        public Dictionary<string, IItem> Items
        {
            get { return _items ?? (_items = new Dictionary<string, IItem>()); }
        }

        // Indicates this is a container
        override
        public bool IsContainer
        {
            get
            {
                return true;
            }
        }

        // Calculates total weight including contents
        override
        public float Weight
        {
            get
            {
                float weight = base.Weight; // Container's own weight
                foreach (IItem item in _items.Values)
                {
                    weight += item.Weight;  // Add weight of each contained item
                }
                return weight;
            }
        }

        // Builds description including contents
        override
        public string Description
        {
            get
            {
                string description = base.Description;
                foreach (IItem item in _items.Values)
                {
                    description += "\n\t" + item.Description; // Append each item's description
                }
                return description;
            }
        }

        // Constructors
        public ItemContainer() : base()
        {
            _items = new Dictionary<string, IItem>();
        }

        
        public ItemContainer(string name, string description, float weight, double volume) : base(name, description, weight, volume)
        {
            _items = new Dictionary<string, IItem>();
        }

        // Adds item to container
        public bool Insert(IItem item)
        {
            Items[item.Name] = item;
            return true;
        }

        // Removes item from container
        public IItem Remove(string itemName)
        {
            if (Items.TryGetValue(itemName, out IItem itemToRemove))
            {
                Items.Remove(itemName);
                return itemToRemove;
            }
            return null;
        }
    }
    }
    

