﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StarterGame
{
    public class LoadCommand : Command
    {
        private readonly GameSaveService _saveService;

        public LoadCommand(GameSaveService saveService) : base()
        {
            this.Name = "load";
            _saveService = saveService;
        }

        public override bool Execute(Player player)
        {
            if (player == null)
            {
                throw new ArgumentNullException(nameof(player));
            }

            _saveService.LoadGame(player);
            return false;
        }
    }
}

