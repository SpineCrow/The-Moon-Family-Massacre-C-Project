﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StarterGame
{
    public class WorldEvent : IWorldEvent
    { 
        private Trigger _trigger; // Trigger for the event
        private Room _toRoom; // Destination room
        private Room _fromRoom; // Source room
        private string _toDirection; // Direction to destination
        private string _fromDirection; // Direction from source

        // Properties
        public Room ToRoom { get { return _toRoom; } }
        public Room FromRoom { get { return _fromRoom; } }
        public string ToDirection { get { return _toDirection; } }
        public string FromDirection { get { return _fromDirection; } }
        public Trigger Trigger { get { return _trigger; } set { _trigger = value; } }

        // Constructor
        public WorldEvent(Room trigger, Room toRoom, Room fromRoom, string toDirection, string fromDirection, string description = "door", string requiredKeyTag = "key")
        {
            _trigger = trigger;
            _toRoom = toRoom;
            _fromRoom = fromRoom;
            _toDirection = toDirection;
            _fromDirection = fromDirection;

        }

        public void Execute()
        {

        }
    }
}
    

