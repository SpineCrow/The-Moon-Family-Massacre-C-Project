﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StarterGame
{
    // Marker interface for game triggers
    public interface Trigger { }

    // Interface for world events that can be triggered
    public interface IWorldEvent
    {
        // The trigger that activates this event
        Trigger Trigger { get; }

        // Method to execute the event
        void Execute();
    }

    // Interface for all items in the game
    public interface IItem
    {
        string Name { get; }
        string Description { get; }
        float Weight { get; }
        double Volume { get; }
        string Id { get; }
        void Decorate(IItem doecorator);
        bool IsContainer { get; }

        // Flag for new items
        bool IsNew { get; set; }
        // Gets formatted item info
        string GetInfo();
    }
    // Interface for containers that can hold items
    public interface IItemContainer : IItem
    {
        // Dictionary of contained items
        Dictionary<string, IItem> Items { get; }
        bool Insert(IItem item);
        IItem Remove(string itemName);
    }

    // Interface for objects that can be shot
    public interface IShootable
    {
        // Behavior when shot by player
        void OnShot(Player player);

        // Name of shootable object
        string Name { get; }
    }
}
