﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StarterGame
{
    // Parses single-word commands (Chain of Responsibility pattern)
    public class MultiCommandParser : CommandParser
    {

        public override Command ParseCommand(string commandString)
        {
            // Shared service for save/load
            var saveService = new GameSaveService();

            // Simple command matching
            if (commandString == "go")
            {
                return new GoCommand();
            }
            if (commandString == "look")
            {
                return new LookCommand();
            }
            if (commandString == "back")
            {
                return new BackCommand();
            }
            if (commandString == "take")
            {
                return new TakeCommand();
            }
            if (commandString == "add")
            {
                return new AddCommand();
            }
            if (commandString == "remove")
            {
                return new RemoveCommand();
            }
            if (commandString == "Shoot")
            {
                return new ShootCommand();
            }
            if (commandString == "load")
            {
                return new LoadCommand(saveService);
            }
            if (commandString == "save")
            {
                return new SaveCommand(saveService);
            }
            if (commandString == "inspect")
            {
                return new InspectCommand();
            }
            if (commandString == "quit")
            {
                return new QuitCommand();
            }
            if (commandString == "say")
            {
                return new SayCommand();
            }
            if (commandString == "help")
            {
                return new HelpCommand();
            }
            // Pass to next parser in chain if no match
            return _nextParser?.ParseCommand(commandString);
        }
    }
    // Parses multi-word commands (Chain of Responsibility pattern)
    public class MultiWordCommandParser : CommandParser
    {
        public override Command ParseCommand(string commandString)
        {
            // Parse commands with parameters
            if (commandString.StartsWith("go"))
            {
                string direction = commandString.Substring(3).Trim();
                return new GoCommand { SecondWord = direction };
            }
            if (commandString.StartsWith("say"))
            {
                string word = commandString.Substring(3).Trim();
                return new SayCommand { SecondWord = word };
            }
            if (commandString.StartsWith("back"))
            {
                string word = commandString.Substring(4).Trim();
                return new BackCommand { SecondWord = word };
            }
            if (commandString.StartsWith("take the"))
            {
                string word = commandString.Substring (5).Trim();
                return new TakeCommand { SecondWord = word };   
            }
            if (commandString.StartsWith("add the"))
            {
                string itemName = commandString.Substring(7).Trim();
                return new AddCommand { SecondWord = itemName };
            }
            if (commandString.StartsWith("remove the"))
            {
                string itemName = commandString.Substring (10).Trim();
                return new RemoveCommand { SecondWord = itemName };
            }
            if (commandString.StartsWith("inspect"))
            {
                string target = commandString.Substring(7).Trim();
                return new InspectCommand { SecondWord = target };
            }
            if (commandString.StartsWith("shoot at the"))
            {
                string target = commandString.Substring(13).Trim();
                return new ShootCommand { SecondWord = target };
            }
            if (commandString.StartsWith("look at"))
            {
                string target = commandString.Substring(8).Trim();
                return new LookCommand { SecondWord = target };
            }
            if (commandString.StartsWith("look for"))
            {
                string target = commandString.Substring(8).Trim();
                return new LookCommand { SecondWord = target };
            }
            // Pass to next parser in chain if no match
            return _nextParser?.ParseCommand(commandString);
        }
    }
}
