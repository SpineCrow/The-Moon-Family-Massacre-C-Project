﻿using System.Collections;
using System.Collections.Generic;
using System;

namespace StarterGame
{
    // Abstract base class for all commands
    public abstract class Command
    {
        private string _name;
        public string Name { get { return _name; } set { _name = value; } }
        private string _secondWord;
        public string SecondWord { get { return _secondWord; } set { _secondWord = value; } }

        public Command()
        {
            this.Name = "";
            this.SecondWord = null; // Initialize with no second word
        }

        public bool HasSecondWord()
        {
            return this.SecondWord != null;// Check if command has a second word
        }

        public abstract bool Execute(Player player); // Abstract method to be implemented by subclasses
    }

}
