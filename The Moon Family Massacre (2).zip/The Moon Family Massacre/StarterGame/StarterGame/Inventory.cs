﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StarterGame
{
    [Serializable] // Allows inventory to be saved
    public class Inventory
    {
        private Dictionary<string, Item> _inventory; // Stores items by ID
        private Capacity _capacity; // Tracks weight/volume limits

        // Constructor sets maximum capacity
        public Inventory(float maxWeight, double maxVolume)
        {
            _inventory = new Dictionary<string, Item>();
            _capacity = new Capacity(maxWeight, maxVolume);
        }

        // Returns a copy of the inventory to prevent external modifications
        public Dictionary<string, Item> Items
        {
            get
            {
                return new Dictionary<string, Item>(_inventory);
            }
        }

        // Checks if an item can be added based on capacity
        public bool CanAddItem(Item item)
        {
            return _capacity.CanAddItem(item);
        }

        // Finds item by name (case-insensitive)
        public Item FindItemByName(string id) 
        {
            // changed to make the comparison case-insensitive when checking inventory
            foreach (var pair in _inventory)
            {
                if (pair.Key.ToLower() == id.ToLower())
                {
                    return pair.Value;
                }
            }
            return null;
        }

        // Adds item to inventory if capacity allows
        public bool AddItem(Item item)
        {
            if (CanAddItem(item))
            {
                    _inventory[item.Id] = item; // This uses item Id as the key
                    _capacity.AddItem(item); // Updates capacity tracking
                NormalMessage($"\nAdded {item.Name} to inventory");
                    return true;
            }
            else
            {
                // Specific feedback about why item can't be added
                if (_capacity.CurrentWeight + item.Weight > _capacity.MaxWeight)
                {
                    ErrorMessage($"\nCannot carry {item.Name}. Weight limit exceeded!");
                }
                if (_capacity.CurrentVolume + item.Volume > _capacity.MaxVolume)
                {
                    ErrorMessage($"\nCannot carry {item.Name}. Volume limit exceeded!");
                }
                return false;
            }
        }

        // Removes item from inventory
        public bool RemoveItem(Item item)
        {
            if (_inventory.Remove(item.Id)) // This uses item Id as the key
            {
                _capacity.RemoveItem(item); // Updates capacity tracking
                NormalMessage($"\nRemoved {item.Name} from inventory");
                return true;
            }
            ErrorMessage($"\nItem {item.Name} not found in inventory.");
            return false;
        }

        // Displays all items in inventory with capacity info
        public void ShowInventory()
        {
            if (_inventory.Count == 0)
            {
                InfoMessage("\nInventory is empty");
                return;
            }

            InfoMessage("\nInventory contents:");
            foreach (Item item in _inventory.Values)
            {
                InfoMessage($"\n- {item.GetInfo()}");
            }
            InfoMessage($"\nTotal weight: {_capacity.CurrentWeight:F1}/{_capacity.MaxWeight:F1} kg");
            InfoMessage($"\nTotal volume: {_capacity.CurrentVolume:F1}/{_capacity.MaxVolume:F1} cubic meters");
        }

        // Clears all items from inventory
        public void Clear()
        {
            _inventory.Clear();
        }

        // Helper methods for colored console output
        private void NormalMessage(string message)
        {
            Console.WriteLine(message);
        }

        private void ErrorMessage(string message)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine(message);
            Console.ResetColor();
        }

        private void InfoMessage(string message)
        {
            Console.WriteLine(message);
        }
    }
}
