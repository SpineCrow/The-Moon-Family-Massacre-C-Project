﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StarterGame
{
    public class TakeCommand : Command
    {
        public TakeCommand() : base()
        {
            this.Name = "take";
        }

        public override bool Execute(Player player)
        {
            player.Take();
            return false;
        }
    }
}
