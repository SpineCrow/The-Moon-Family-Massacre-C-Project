﻿using System.Collections;
using System.Collections.Generic;
using System;
using System.IO;
using System.Linq;
using System.ComponentModel.Design;

namespace StarterGame
{


    // Interface for room delegates (decorator pattern)
    public interface IRoomDelegate
    {

        Room OnGetExit(string roomName, Room room, Player player);
        Room ContainingRoom { get; set; }
    }

    // Trap room that requires items to pass
    public class TrapRoom : IRoomDelegate
    {
        private ConsoleColor _unlockColor; // Add this field for unlock message color for TrapRooms

        private bool _engaged; // Whether trap is active

        public bool Engaged
        {
            set { _engaged = value; }
            get { return _engaged; }
        }

        // Items needed to pass
        private HashSet<string> _requiredItemNames;

        // Password (unused in current implementation)
        private string _password;

        // Message when unlocked
        private string _unlockMessage;

        // Message when locked
        private string _lockedMessage;

        // Room containing this delegate
        private Room _containingRoom;

        // Stores the room being locked (e.g., Butcher_Closet)
        private Room _lockedRoom;

        public Room ContainingRoom
        {
            set { _containingRoom = value; }
            get { return _containingRoom; }
        }




        //public TrapRoom() : this("please") { }

        //Constructor that handles say passwords
        //public TrapRoom(string password)
        //{
        //_password = password;
        //Engaged = true;
        //NotificationCenter.Instance.AddObserver("PlayerDidSaySomething", PlayerDidSaySomething);
        //NotificationCenter.Instance.AddObserver("PlayerDidEnterRoom", Execute);
        //_password = "please";
        //}

        // Constructor for single required item
        public TrapRoom(string requiredItemName) : this(new List<string> { requiredItemName }, $"The {requiredItemName} fits! The path is now unlocked.") { }

        // Constructor handles multiple keys
        public TrapRoom(List<string> requiredItemNames, string unlockMessage = null, string lockedMessage = null, Room lockedRoom = null, ConsoleColor unlockColor = ConsoleColor.Green)
        {
            _requiredItemNames = new HashSet<string>(requiredItemNames);
            _unlockMessage = unlockMessage ?? $"The required items fit! The path is now unlocked.";
            _lockedMessage = lockedMessage ?? GetLockMessage();
            _lockedRoom = lockedRoom; // Set the locked room
            _unlockColor = unlockColor;
            Engaged = true;
            NotificationCenter.Instance.AddObserver("PlayerDidEnterRoom", PlayerDidEnterRoom);
        }

        // Called when player tries to get an exit from the room
        public Room OnGetExit(string roomName, Room room, Player player)
        {
            if (_engaged && room == _lockedRoom)
            {
                bool hasRequirements = CheckPlayerInventory(player);

                if (!hasRequirements)
                {
                    player.ErrorMessage(_lockedMessage ?? GetLockMessage());
                    return null; // Block forward exit
                }

                _engaged = false;
                player.NormalMessage(_unlockMessage);
            }
            return room;
        }


        // Check if player has required items
        private bool CheckPlayerInventory(Player player)
        {
            //Add null checks
            if (player == null || player.InventoryItems == null)
            {
                return false;
            }
            foreach (string requiredName in _requiredItemNames)
            {
                // Check if any item matches (case-insensitive)
                bool hasItem = player.InventoryItems.Values
                    .Any(item => item != null &&
                        string.Equals(item.Name, requiredName, StringComparison.OrdinalIgnoreCase));

                if (!hasItem)
                {
                    return false;
                }
            }
            return true;
        }


        // Generate lock message based on required items
        private string GetLockMessage()
        {
            if (_requiredItemNames.Count == 1)
                return $"You need {_requiredItemNames.First()} to proceed!";
            else
                return $"You need: {string.Join(", ", _requiredItemNames)}";
        }

        // Handle player entering room
        public void PlayerDidEnterRoom(Notification notification)
        {
            Player player = (Player)notification.Object;
            if (player != null && player.CurrentRoom == ContainingRoom)
            {
                //Checks if the player has all required items using FindItemInInventory
                bool hasAllItems = true;

                foreach (string requiredTag in _requiredItemNames)
                {
                    bool foundItem = false;

                    foreach (Item item in player.InventoryItems.Values)
                    {
                        if (item.Name.Equals(requiredTag, StringComparison.OrdinalIgnoreCase))
                        {
                            foundItem = true;
                            break; //This will exit early if found
                        }
                    }
                    //if there is one required item missing, set to false
                    if (!foundItem)
                    {
                        hasAllItems = false;
                        break;
                    }
                }
                if (hasAllItems)
                {
                    Engaged = false;
                    player.ColoredMessage(_unlockMessage, _unlockColor);
                    // Consumes the keys (remove from inventory)
                    foreach (var tag in _requiredItemNames)
                    {
                        Item itemToRemove = null; //Defaults to "not found"
                        foreach (var item in player.InventoryItems.Values)
                        {
                            if (item.Name.Equals(tag, StringComparison.OrdinalIgnoreCase))
                            {
                                itemToRemove = item; //Stores matching item
                                break; //exits early after finding the first match
                            }
                        }
                        if (itemToRemove != null)
                        {
                            player.RemoveFromInventory(itemToRemove);
                        }
                    }
                }
                else if (_engaged)
                {
                    var missingItems = new List<string>();
                    foreach (var tag in _requiredItemNames)
                    {
                        bool hasItem = false;
                        foreach (var item in player.InventoryItems.Values)
                        {
                            if (item.Name.Equals(tag, StringComparison.OrdinalIgnoreCase))
                            {
                                hasItem = true;
                                break; //This will exit early if found
                            }
                        }
                        if (!hasItem)
                        {
                            missingItems.Add(tag); //Add to missing items if not found
                        }
                    }
                    if (_requiredItemNames.Count == 1)
                    {
                        player.ErrorMessage($"You still need the {missingItems.First()}.");
                    }
                    else
                    {
                        player.ErrorMessage($"You're still missing: {string.Join(", ", missingItems)}");
                    }
                }
            }
        }


        // Unused in current implementation
        public void Execute(Notification notification)
        {
            NotificationCenter.Instance.AddObserver("PlayerDidSaySomething", PlayerDidSaySomething);
        }

        // Unused in current implementation
        public void PlayerDidSaySomething(Notification notification)
        {
            Player player = (Player)notification.Object;
            if (player != null)
            {
                if (player.CurrentRoom.Equals(ContainingRoom))
                {
                    Dictionary<string, object> userInfo = notification.UserInfo;
                    string word = null;
                    Object wordObject = null;
                    if (userInfo != null)
                    {
                        userInfo.TryGetValue("word", out wordObject);
                        if (wordObject != null)
                        {
                            word = wordObject.ToString();
                        }
                    }
                    if (word != null)
                    {
                        if (word.Equals(_password))
                        {
                            Engaged = false;
                        }
                        else
                        {
                            player.ErrorMessage("You didn't say the magic word. Ha, Ha, Ha!");
                        }
                    }
                }
            }
        }
    }



    // Echo room that repeats what player says
    public class EchoRoom : IRoomDelegate
    {
        public EchoRoom()
        {
            NotificationCenter.Instance.AddObserver("PlayerDidSaySomething", PlayerDidSaySomething);
        }
        public Room OnGetExit(string roomName, Room room, Player player)
        {
            return room;
        }
        public Room ContainingRoom { get; set; }

        public void PlayerDidSaySomething(Notification notification)
        {
            Player player = (Player)notification.Object;
            if (player != null)
            {
                if (player.CurrentRoom.Equals(ContainingRoom))
                {
                    Dictionary<string, object> userInfo = notification.UserInfo;
                    string word = null;
                    Object wordObject = null;
                    if (userInfo != null)
                    {
                        userInfo.TryGetValue("word", out wordObject);
                        if (wordObject != null)
                        {
                            word = wordObject.ToString();
                        }
                    }
                    player.InfoMessage(word + "... " + word + "... " + word + "...");
                }
            }
        }
    }

    // Base room class
    public class Room : Trigger
    {
        private Dictionary<string, Room> _exits; // Room exits
        private Dictionary<string, IItem> _itemsDictionary = new Dictionary<string, IItem>(); // Items in room
        private string _tag; // Room description/tag
        private IRoomDelegate _delegate; // Optional delegate for special behavior

        public Dictionary<string, Room> Exits
        {
            get { return _exits; }
            private set { _exits = value; }
        }

        public IRoomDelegate Delegate
        {
            set
            {
                if (value == null)
                {
                    // Free the delegate if it exists
                    if (_delegate != null)
                    {
                        _delegate.ContainingRoom = null;
                        _delegate = value;
                    }
                }
                else
                {
                    if (value.ContainingRoom != null)
                    {
                        // Free the delegate
                        value.ContainingRoom.Delegate = null;
                    }
                    value.ContainingRoom = this;
                    _delegate = value;
                }
            }
            get
            { 
                return _delegate; 
            }
        }


        public string Tag { get { return _tag; } set { _tag = value; } }
        public Dictionary<string, IItem> Items { get {  return _itemsDictionary; } }

        // Default constructor
        public Room() : this("No Tag"){}

        private IItem _floor;

        // Designated Constructor
        public Room(string tag)
        {
            _exits = new Dictionary<string, Room>();
            _itemsDictionary = new Dictionary<string, IItem>();
            this.Tag = tag;
            Delegate = null;
        }

        // Set an exit
        public void SetExit(string exitName, Room room)
        {
            _exits[exitName] = room;
        }

        // Get an exit (with delegate processing)
        public Room GetExit(string exitName, Player player = null)
        {
            Room room = null;
            _exits.TryGetValue(exitName, out room);

            // Only check delegate if player exists (enemies bypass traps)
            if (player != null && Delegate != null)
            {
                room = Delegate.OnGetExit(exitName, room, player);
            }
            return room;
        }

        // Get all exits as string
        public string GetExits()
        {
            string exitNames = "Exits: ";
            //Dictionary<string, Room>.KeyCollection keys = _exits.Keys;
            foreach (string exitName in Exits.Keys)
            {
                exitNames += " " + exitName;
            }

            return exitNames;
        }

        // Room description
        public string Description()
        {
            return this.Tag + ".\n *** " + this.GetExits();
        }

        // Legacy item pickup
        public IItem Pickup(string itemName)
        {
            IItem tempItem = null;
            if (_floor != null)
            {
                if (_floor.Name.Equals(itemName))
                {
                    tempItem = _floor;
                    _floor = null;
                    return tempItem;
                }
            }
            return tempItem;
        }

        // Legacy item drop
        public void Drop(IItem item)
        {
            _floor = item;
        }

        // Add item to room
        public void AddItem(IItem item)
        {
            if (item is Item concreteItem)
            {
                concreteItem.IsNew = true;
            }
            _itemsDictionary[item.Name] = item;
        }

        public void AddItem(Item item)
        {
            AddItem((IItem)item);
        }

        // Remove item from room
        public void RemoveItem(Item item)
        {
            _itemsDictionary.Remove(item.Name);
        }

    }
}
