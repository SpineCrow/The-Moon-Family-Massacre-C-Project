﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StarterGame
{
    public class SaveCommand : Command
    {
        private readonly GameSaveService _saveService;

        public SaveCommand(GameSaveService saveService) : base()
        {
            this.Name = "save";
            _saveService = saveService;
        }

        public override bool Execute(Player player)
        {
            if (player == null)
            {
                throw new ArgumentNullException(nameof(player));
            }

            _saveService.SaveGame(player);
            return false;
        }
    }
}
