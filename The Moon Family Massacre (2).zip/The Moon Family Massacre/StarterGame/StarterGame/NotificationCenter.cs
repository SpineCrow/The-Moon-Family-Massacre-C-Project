﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices.ObjectiveC;
using System.Text;
using System.Threading.Tasks;

namespace StarterGame
{
    public class NotificationCenter
    {
        // Stores observers for each notification name
        private Dictionary<String, EventContainer> observers;

        // Singleton instance
        private static NotificationCenter _instance;

        // Singleton accessor
        public static NotificationCenter Instance
        {
            get
            {
                if(_instance == null)
                {
                    _instance = new NotificationCenter();
                }
                return _instance;
            }
        }
        public NotificationCenter()
        {
            observers = new Dictionary<String, EventContainer>();
        }

        // Nested class to manage observers for a specific notification
        private class EventContainer
        {
            private event Action<Notification> Observer; // Event for notification callbacks
            public EventContainer()
            {
            }

            // Add an observer to the event
            public void AddObserver(Action<Notification> observer)
            {
                Observer += observer;
            }

            // Remove an observer from the event
            public void RemoveObserver(Action<Notification> observer)
            {
                Observer -= observer;
            }

            // Trigger all observers for this notification
            public void SendNotification(Notification notification)
            {
                Observer(notification);
            }

            // Check if there are any observers
            public bool IsEmpty()
            {
                return Observer == null;
            }
        }

        // Public method to add an observer for a notification
        public void AddObserver(String notificationName, Action<Notification> observer)
        {
            if(!observers.ContainsKey(notificationName))
            {
                observers[notificationName] = new EventContainer();
            }
            observers[notificationName].AddObserver(observer);
        }

        // Public method to remove an observer
        public void RemoveObserver(String notificationName, Action<Notification> observer)
        {
            if(observers.ContainsKey(notificationName))
            {
                observers[notificationName].RemoveObserver(observer);
                if(observers[notificationName].IsEmpty())
                {
                    observers.Remove(notificationName);
                }
            }
        }

        // Post a notification to all registered observers
        public void PostNotification(Notification notification)
        {
            if(observers.ContainsKey(notification.Name))
            {
                observers[notification.Name].SendNotification(notification);
            }
        }
    }
}
