﻿using System.Collections;
using System.Collections.Generic;
using System;
using System.ComponentModel.Design;
using System.Numerics;
using System.Linq;

namespace StarterGame
{
    /*
     * Fall 2024
     */
    public class Player
    {
        // Current room the player is in
        private Room _currentRoom = null;

        // Player's inventory
        private Inventory _inventory = new Inventory(40f, 40.0);

        // Player's carrying capacity
        private Capacity _capacity;

        //Tracks where the player went to before
        private Stack<Room> _roomHistory = new Stack<Room>();

        // Properties
        public Room CurrentRoom { get { return _currentRoom; } set { _currentRoom = value; } }
        public float MaxWeight { get { return _capacity.MaxWeight; } }
        public double MaxVolume { get { return _capacity.MaxVolume; } }
        public float CurrentWeight { get { return _capacity.CurrentWeight; } }
        public double CurrentVolume { get { return _capacity.CurrentVolume; } }
        public Dictionary<string, Item> InventoryItems => _inventory.Items;




        // Constructor
        public Player(Room room, Capacity capacity)
        {
            _currentRoom = room;
            _capacity = capacity;
            _inventory = new Inventory(capacity.MaxWeight, capacity.MaxVolume);
            // Register player with game world
            GameWorld.Instance.SetPlayer(this);
        }


        // Helps the player go back whenever trapped in a room
        public bool TryGoBack()
        {
            if(_roomHistory.Count == 0)
                return false;

            //Store the current room before moving
            Room currentRoom = _currentRoom;

            //Pop the previous room from history
            Room previousRoom = _roomHistory.Pop();
            CurrentRoom = previousRoom;

            //Notifies the game (but now it skips TrapRoom checks for backtracking)
            NotificationCenter.Instance.PostNotification(new Notification("PlayerEnteredRoom", this));
            NormalMessage("\nYou returned to:" + CurrentRoom.Tag);

            return true;
        }

        // Move player in specified direction
        public void WaltTo(string direction)
        {
            Room nextRoom = this.CurrentRoom.GetExit(direction, this);
            if (nextRoom != null)
            {
                // Check for enemies in the new room
                foreach (var enemy in GameWorld.Instance.GetEnemiesInRoom(nextRoom))
                {
                    this.WarningMessage($"You see the {enemy.Name} in the room!");
                }
                _roomHistory.Push(CurrentRoom); //Records the current room before moving
                CurrentRoom = nextRoom;
                Notification notification = new Notification("PlayerEnteredRoom", this);
                NotificationCenter.Instance.PostNotification(notification);
                NormalMessage("\n" + this.CurrentRoom.Description());
            }
            else
            {
                ErrorMessage("\nThere is no door on " + direction);
            }
            NotificationCenter.Instance.PostNotification(new Notification("PlayerDidSomething", this));
        }

        // Inventory management methods
        public bool AddToInventory(Item item)
        {
            return _inventory.AddItem(item);
        }

        public void RemoveFromInventory(Item item)
        {
            _inventory.RemoveItem(item);
        }

        public Item FindItemInInventory(string name)
        {
            return _inventory.FindItemByName(name);
        }

        public void ClearInventory()
        {
            _inventory.Clear();
        }

        //Helps clear the room history stack
        public void ClearRoomHistory()
        {
            _roomHistory.Clear();
        }


        //Finds a shootable target for the player
        private object FindShootableTarget(string targetName)
        {
            //Checks item in the current room
            foreach (Item item in CurrentRoom.Items.Values)
            {
                if (string.Equals(item.Name, targetName, StringComparison.OrdinalIgnoreCase))
                {
                    // Found the matching item
                    return item;
                }
            }

            //Checks enemies in current room
            foreach (Enemy enemy in GameWorld.Instance.Enemies)
            {
                if (string.Equals(enemy.Name, targetName, StringComparison.OrdinalIgnoreCase)
                    && enemy.CurrentRoom == this.CurrentRoom)
                {
                    //Found the matching enemy
                    return enemy;
                }
            }
            //No target was found
            return null;
        }

        // Gives the player an option to shoot an object
        public void Shoot(string targetName)
        {
            // Check if player has a gun
            bool hasGun = false;
            foreach (Item item in InventoryItems.Values)
            {
                if (string.Equals(item.Name, "Gun", StringComparison.OrdinalIgnoreCase))
                {
                    hasGun = true;
                    break;
                }
            }
            if (!hasGun)
            {
                ErrorMessage("\nYou need a gun to shoot!");
                return; 
            }
            //Finds the target
            object target = FindShootableTarget(targetName);
            if (target == null)
            {
                WarningMessage($"\nThere is no {targetName} here to shoot.");
                return;
            }

            //Handle shooting
            if (target is IShootable shootable)
            {
                shootable.OnShot(this); // Trigger shootable behavior
            }
            NotificationCenter.Instance.PostNotification(new Notification("PlayerDidSomething", this));
        }




        // Inspect an item
        public void Inspect(string itemName)
        {
            // First check if the item exists in the room
            if (CurrentRoom.Items.TryGetValue(itemName, out IItem itemToInspect))
            {
                // Handle ItemContainer specially
                if (itemToInspect is IItemContainer container)
                {
                    InfoMessage($"{itemName} is {itemToInspect.Description}");
                    if (container.Items.Count > 0)
                    {
                        InfoMessage("It contains:");
                        foreach (var item in container.Items.Values)
                        {
                            InfoMessage($"- {item.Name}: {item.Description}");
                        }
                    }
                    else
                    {
                        InfoMessage("It's empty.");
                    }
                }
                else
                {
                    InfoMessage($"{itemName} is {itemToInspect.Description}");
                }
            }
            else
            {
                ErrorMessage($"There is no '{itemName}' here to inspect.");
            }
        }

        // Take first available item from a container
        public void Take()
        {
            // Find first container in room (like a chest)
            var container = CurrentRoom.Items.Values
                            .FirstOrDefault(i => i is IItemContainer) as IItemContainer;

            if (container == null)
            {
                ErrorMessage("There's nothing here to take from.");
                return;
            }

            if (container.Items.Count == 0)
            {
                InfoMessage($"{container.Name} is empty.");
                return;
            }

            // Take first available item
            var item = container.Items.Values.First();
            if (AddToInventory((Item)item))
            {
                container.Remove(item.Name);
                NormalMessage($"You took {item.Name}.");
            }
        }


        // Look at room or inventory
        public void Look(string target)
        {
            Room room = this.CurrentRoom;

            if (string.IsNullOrEmpty(target))
            {
                NormalMessage($"\n{room.Description()}.");

                if (room.Items.Count > 0)
                {
                    NormalMessage("You notice something interesting in the area:");
                    foreach (Item item in room.Items.Values)
                    {
                        NormalMessage($"- {item.Name}: {item.Description}");
                    }
                }
                else
                {
                    NormalMessage("There are no items in this area.");
                }
            }
            else if (target.ToLower() == "inventory")
            {
                if (InventoryItems.Count == 0)
                {
                    NormalMessage("Your inventory is empty.");
                }
                else
                {
                    NormalMessage("You're currently carrying:");
                    foreach (Item item in InventoryItems.Values)
                    {
                        NormalMessage($"- {item.Name}: {item.Description}");
                    }
                }
            }
            else
            {
                //This searches for an item by Tag 
                Item foundItem = null;
                foreach (Item i in room.Items.Values)
                {
                    if (i.Name.ToLower() == target.ToLower())
                    {
                        foundItem = i;
                        break;
                    }
                }
                if (foundItem != null)
                {
                    NormalMessage($"\nYou look at the {foundItem.Name}: {foundItem.Description}.");
                }
                else
                {
                    WarningMessage($"\nYou don't see a '{target}' here.");
                }
            }
        }

        // Add item to inventory
        public void Add(string itemName)
        {
            Room room = this.CurrentRoom;

            if (string.IsNullOrEmpty(itemName))
            {
                WarningMessage("Please specify an item to add");
                return;
            }

            // Search for the item by name (case-insensitive)
            Item itemToAdd = null;
            foreach (Item i in room.Items.Values)
            {
                if (i.Name.ToLower() == itemName.ToLower())
                {
                    itemToAdd = i;
                    break;
                }
            }

            if (itemToAdd != null)
            {
                if (AddToInventory(itemToAdd))
                {
                    room.RemoveItem(itemToAdd); // Remove the item from the room after picking it up
                    NormalMessage($"You added {itemToAdd.Name} to your inventory.");
                }
            }
            else
            {
                WarningMessage($"There is no '{itemName}' here to add");
            }
            NotificationCenter.Instance.PostNotification(new Notification("PlayerDidSomething", this));
        }


        // Remove item from inventory
        public void Remove(string itemName)
        {
            if (string.IsNullOrEmpty(itemName))
            {
                WarningMessage("Please specify an item to remove.");
                return;
            }

            // Search for the item in inventory by name (case-insensitive)
            Item itemToRemove = null;
            foreach (Item i in InventoryItems.Values)
            {
                if (i.Name.ToLower() == itemName.ToLower())
                {
                    itemToRemove = i;
                    break;
                }
            }

            if (itemToRemove != null)
            {
                RemoveFromInventory(itemToRemove);
                CurrentRoom.AddItem(itemToRemove); // Optionally add it back to the current room
                NormalMessage($"You removed {itemToRemove.Name} from your inventory.");
            }
            else
            {
                WarningMessage($"You don't have '{itemName}' in your inventory.");
            }
        }
            
        //Kills off the player if they encounter the butcher (without required items)
        public void Die()
        {
            ErrorMessage("\nYOU ARE DEAD! The butcher added you to the family...");
            NotificationCenter.Instance.PostNotification(new Notification("PlayerDied", this));
        }


        // Say something (can trigger events)
        public void Say(string word)
        {
            NormalMessage(word);
            Dictionary<string, object> userInfo = new Dictionary<string, object>();
            userInfo["word"] = word;
            Notification notification = new Notification("PlayerDidSaySomething", this, userInfo);
            NotificationCenter.Instance.PostNotification(notification);
        }

        // Message display methods with different colors
        public void OutputMessage(string message)
        {
            Console.WriteLine(message);
        }

        public void ColoredMessage(string message, ConsoleColor newColor)
        {
            ConsoleColor oldColor = Console.ForegroundColor;
            Console.ForegroundColor = newColor;
            OutputMessage(message);
            Console.ForegroundColor = oldColor;
        }

        public void NormalMessage(string message)
        {
            ColoredMessage(message, ConsoleColor.White);
        }

        public void InfoMessage(string message)
        {
            ColoredMessage(message, ConsoleColor.Blue);
        }

        public void WarningMessage(string message)
        {
            ColoredMessage(message, ConsoleColor.DarkYellow);
        }

        public void ErrorMessage(string message)
        {
            ColoredMessage(message, ConsoleColor.Red);
        }
    }

}
