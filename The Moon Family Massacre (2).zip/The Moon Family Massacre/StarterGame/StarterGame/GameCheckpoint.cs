﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StarterGame
{
    // Memento pattern for saving game state
    [Serializable]
    public class GameCheckpoint
    {
        public Room PlayerRoom { get; set; }  // Player's current room
        public Dictionary<string, Item> Inventory { get; set; } // Player's inventory

        public GameCheckpoint(Room room, Dictionary<string, Item> inventory)
        {
            PlayerRoom = room;
            // Clone or deep copy inventory
            Inventory = new Dictionary<string, Item>(inventory);
        }
    }
}
