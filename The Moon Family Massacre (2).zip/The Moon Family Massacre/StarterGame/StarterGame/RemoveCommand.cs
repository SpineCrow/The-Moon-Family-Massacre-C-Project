﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StarterGame
{
    public class RemoveCommand : Command
    {
            public RemoveCommand() : base()
            {
                this.Name = "remove";
            }

            override
            public bool Execute(Player player)
            {
                if (this.HasSecondWord())
                {
                    player.Remove(this.SecondWord);
                }
                else
                {
                    player.WarningMessage("\nRemove what?");
                }
                return false;
            }
        }
    }
