﻿using System.Collections;
using System.Collections.Generic;
using System;

namespace StarterGame
{
    /*
     * Fall 2024
     */
    public class Parser
    {
        // Available commands
        private CommandWords _commands;
        // Chain of responsibility pattern for parsing
        private CommandParser _firstParser;

        public Parser() : this(new CommandWords()){}

        // Designated Constructor
        public Parser(CommandWords newCommands)
        {
            _commands = newCommands;

            // Set up chain of responsibility for command parsing
            var simpleParser = new MultiCommandParser();
            var multiWordParser = new MultiWordCommandParser();

            simpleParser.SetNextParser(multiWordParser);

            _firstParser = simpleParser;
        }

        // Parse a command string into a Command object
        public Command ParseCommand(string commandString)
        {
            return _firstParser.ParseCommand(commandString);
        }

        // Get description of available commands
        public string Description()
        {
            return _commands.Description();
        }
    }
}
