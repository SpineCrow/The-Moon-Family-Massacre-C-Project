﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StarterGame
{
    public class Enemy
    {
        private Room _currentRoom;
        private Player _playerToTrack;
        private string _name;
        // This determines how many rooms away the enemy will be able to detect the player
        private int _aggressionRange;
        //Stores the enemy's default position
        private Room _defaultRoom;
        private int _moveCooldown = 0;
        private const int MOVE_COOLDOWN_MAX = 1; // Moves every 3 player actions

        //List of items needed to defeat the butcher
        public List<string> BanishmentItems { get; } = new List<string>()
        {
            "Flesh Butcher's Knife",
            "Final Purified Photo",
            "Silver Crossed Water",
            "Holy Essence",
            "Eye of Truth",
            "Severed Tongue"
        };

        public Room CurrentRoom
        {
            get { return _currentRoom; }
            set
            {
                if (CurrentRoom != null)
                {

                }
                _currentRoom = value;
                if (_currentRoom != null)
                {

                }
            }
        }

        public string Name { get { return _name; } }
        public Enemy(string name, Room startingRoom, int aggressionRange = 3)
        {
            _name = name;
            _aggressionRange = aggressionRange;
            CurrentRoom = startingRoom;
            _defaultRoom = startingRoom;

            //Subscribe to player movement notifications
            NotificationCenter.Instance.AddObserver("PlayerDidSomething", PlayerActed);
            NotificationCenter.Instance.AddObserver("PlayerEnteredRoom", PlayerMoved);
        }


        private void PlayerMoved(Notification notification)
        {
            Player player = (Player)notification.Object;
            if (player == null) return;

            // Track the player's location
            _playerToTrack = player;

            // If player is nearby, move toward them
            if (IsPlayerNearby(player))
            {
                MoveTowardPlayer();
            }
        }

        private void MoveTowardPlayer()
        {
            if (_playerToTrack == null || _currentRoom == null) return;

            //Simple implementation: move randomly towards player

            //Get all possible exits from the current room
            var exits = _currentRoom.GetExits();

            //Lets the Butcher move randomly
            Random rand = new Random();
            var exitList = new List<string>(exits.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries));
            exitList.Remove("Exits:"); //Cleans up the exit string

            if (exitList.Count > 0)
            {
                string randomExit = exitList[rand.Next(exitList.Count)];
                //Pass null for player since enemy movement is not blocked by traps
                Room nextRoom = _currentRoom.GetExit(randomExit, null);

                if (nextRoom != null)
                {
                    // Notify game world of movement
                    NotificationCenter.Instance.PostNotification(new Notification("ButcherMoved", this, new Dictionary<string, object> { { "fromRoom", _currentRoom }, { "toRoom", nextRoom } }));
                    CurrentRoom = nextRoom;
                }
            }
        }

        private bool IsPlayerNearby(Player player)
        {
            // Simple proximity check
            if (player.CurrentRoom == CurrentRoom) return true;

            // Check if player is within aggression range by checking room connections
            return IsWithinRange(player.CurrentRoom, CurrentRoom, _aggressionRange);
        }

        //pathfinding algorithm
        //checks if the player is within a certain range from the enemy
        private bool IsWithinRange(Room start, Room target, int range, int currentDepth = 0, HashSet<Room> visited = null)
        {
            //if visited is null, initialize it as a new hashset
            if (visited == null) visited = new HashSet<Room>();
            //if the player is out of range, return false
            if (currentDepth > range) return false;
            //If player is in range, return true
            if (start == target) return true;

            //Mark the current room as visited
            visited.Add(start);

            foreach (var exit in start.Exits.Values)
            {
                if (exit != null && !visited.Contains(exit))
                {
                    //Skip null exits or already visited rooms.

                    //Recursively call IsWithinRange with the next room, incrementing currentDepth.
                    //if the recursive call returns true, the player is nearby
                    if (IsWithinRange(exit, target, range, currentDepth + 1, visited))
                        return true;
                }
            }

            return false;
        }

        //Method that calls the enemy to kill the player
        public void AttackPlayer(Player player)
        {
            if (player.CurrentRoom != CurrentRoom) return;

            bool hasAllItems = BanishmentItems.All(item => 
            player.InventoryItems.Values.Any(i => 
            i.Name.Equals(item, StringComparison.OrdinalIgnoreCase)));

            if (hasAllItems)
            {
                player.NormalMessage($"\nThe {Name} recoils in fear from your sacred items!");
                CurrentRoom = null; // Remove enemy
                // Use notification system instead of direct Win() call
                NotificationCenter.Instance.PostNotification(new Notification("PlayerWon", player));
                return;
            }
            // Player doesn't have required items - instant death
            player.ErrorMessage($"\nThe {Name} attacks you mercilessly!");
            player.ErrorMessage("You didn't have the required items to defend yourself!");
            player.Die(); //Removes player and ends game
        }

        //Method that follows how much can the enemy move
        private void PlayerActed(Notification notification)
        {
            if (_moveCooldown > 0)
            {
                _moveCooldown--; // Decrement cooldown
                return;
            }

            // Reset cooldown
            _moveCooldown = MOVE_COOLDOWN_MAX;

            // Don't move if in same room as player
            if (_playerToTrack != null && _playerToTrack.CurrentRoom == CurrentRoom)
                return;

            // 50% chance to move when not in combat
            if (CurrentRoom != null && new Random().Next(1) == 0)
            {
                MoveRandomly();
            }
        }

        //Has the enemy move randomly around the house
        private void MoveRandomly()
        {
            if (CurrentRoom == null || CurrentRoom.Exits.Count == 0)
                return;

            var exitList = CurrentRoom.Exits.Keys.ToList();
            string randomExit = exitList[new Random().Next(exitList.Count)];
                Room nextRoom = _currentRoom.GetExit(randomExit, null);
                if (nextRoom != null)
                {
                    MoveTo(nextRoom);
                }
            }
        

        public void StopTracking()
        {
            _playerToTrack = null; // Stop tracking player
        }
    

    public void MoveTo(Room nextRoom)
        {
            Console.WriteLine($"The Butcher is moving from {_currentRoom?.Tag} to {nextRoom?.Tag}");
            // Notify game world of movement
            NotificationCenter.Instance.PostNotification(new Notification("EnemyMoved", this, new Dictionary<string, object>
            { { "fromRoom", _currentRoom }, { "toRoom", nextRoom },
            }));
            _currentRoom = nextRoom;
        }
    }
}

