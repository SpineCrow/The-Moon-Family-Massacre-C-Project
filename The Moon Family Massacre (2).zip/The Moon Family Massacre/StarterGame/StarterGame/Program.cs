﻿using System;

namespace StarterGame
{
    /*
     * Fall 2024
     */
    class Program
    {
        static void Main(string[] args)
        {
            Game game = new Game(); // Create game instance
            game.Start(); // Initialize game
            game.Play();   // Run main game loop
            game.End(); // Clean up and exit
        }
    }
}
