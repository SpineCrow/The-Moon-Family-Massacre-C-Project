﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StarterGame
{

    //A memento that stores the game state
    [Serializable]
    public class GameMemento
    {
        public string PlayerRoomTag { get; }
        public List<Item> InventoryItems { get; }
        public string CheckpointRoomTag { get; }
        public List<Item> CheckpointInventory { get; }

        public GameMemento(string playerRoomTag, List<Item> inventoryItems,
                         string checkpointRoomTag, List<Item> checkpointInventory)
        {
            PlayerRoomTag = playerRoomTag;
            InventoryItems = inventoryItems;
            CheckpointRoomTag = checkpointRoomTag;
            CheckpointInventory = checkpointInventory;
        }
    }
}
