﻿using System.Collections;
using System.Collections.Generic;

namespace StarterGame
{
    /*
     * Fall 2024
     */
    public class GoCommand : Command
    {

        public GoCommand() : base()
        {
            this.Name = "go";
        }

        override
        public bool Execute(Player player)
        {
            if (this.HasSecondWord())
            {
                string direction = this.SecondWord;
                player.WaltTo(direction); // walk to the location specified in SecondWord
            }
            else
            {
                player.WarningMessage("\nGo Where?");
            }
            return false;
        }
    }
}
